package com.online.online_mistry;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import de.hdodenhof.circleimageview.CircleImageView;

public class SettingsActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView phoneNumber, UserName;
    private FirebaseAuth mAuth;
    private DatabaseReference regRef, rootref;
    private FirebaseUser currentUser;
    private static final int GalleryPick = 1;
    String currentUserID;
    private Button SettingVerifiedButton, uploadDocumentButton, membersButton, logoutButton;
    private CircleImageView userProfileImage;
    private StorageReference userProfileImagesRef, uploadToDatabase;
    private ProgressDialog loadingBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        //firebase
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        regRef = FirebaseDatabase.getInstance().getReference();
        currentUserID = mAuth.getCurrentUser().getUid();
        rootref = FirebaseDatabase.getInstance().getReference().child("Shops").child(currentUserID);
        userProfileImagesRef = FirebaseStorage.getInstance().getReference().child("Shop User");

        uploadToDatabase = FirebaseStorage.getInstance().getReference();


        //initialization
        SettingVerifiedButton = (Button) findViewById(R.id.setting_verified);
        uploadDocumentButton = (Button) findViewById(R.id.update_document);
        membersButton = (Button) findViewById(R.id.shop_memebers);
        logoutButton = (Button) findViewById(R.id.Logout);
        phoneNumber = (TextView) findViewById(R.id.user_profile_number);
        UserName = (TextView) findViewById(R.id.user_profile_name);
        userProfileImage = (CircleImageView) findViewById(R.id.user_profile_image);


        mToolbar = (Toolbar) findViewById(R.id.setting_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Settings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        //logout Alert
        final AlertDialog.Builder logoutBuiler = new AlertDialog.Builder(this, R.style.OlmDialogTheme);


        VerifiedProfile();


        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutBuiler.setTitle("Confirm Logout ?");
                logoutBuiler.setMessage(" Do you really want to Logout?");
                logoutBuiler.setCancelable(false);
                logoutBuiler.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mAuth.signOut();
                        Intent senduserLogin = new Intent(SettingsActivity.this, PhoneAuthActivity.class);
                        startActivity(senduserLogin);
                    }
                });
                logoutBuiler.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //dismiss
                    }
                });
                logoutBuiler.show();
            }
        });

        userProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, GalleryPick);
            }
        });


    }

    private void VerifiedProfile() {

        try {

            regRef.child("Shops").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child(currentUserID).child("Verified").getValue().equals("true")) {
                        SettingVerifiedButton.setText("Verified");
                        SettingVerifiedButton.getBackground().setColorFilter(SettingVerifiedButton.getContext().getResources().getColor(R.color.colorBlue), PorterDuff.Mode.SRC);
                        ;

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        } catch (Exception e) {
            Toast.makeText(SettingsActivity.this, "Internet Problem", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GalleryPick && resultCode == RESULT_OK && data != null) {

            Uri ImageUri = data.getData();

            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }



        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {

            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            Toast.makeText(SettingsActivity.this, "test :-"+result, Toast.LENGTH_LONG).show();

            if (resultCode == RESULT_OK) {
                loadingBar.setTitle("Set Profile Image");
                loadingBar.setMessage("Please wait profile Image is Uploading......");
                loadingBar.setCanceledOnTouchOutside(false);
                loadingBar.show();
                Uri resultUri = result.getUri();


                Toast.makeText(SettingsActivity.this, "test ", Toast.LENGTH_LONG).show();

                final StorageReference filepath = userProfileImagesRef.child(currentUserID + ".jpg");
                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(SettingsActivity.this, "Profile Image Uploaded!!!", Toast.LENGTH_LONG).show();
                            final String downloadUrl = userProfileImagesRef.child(currentUserID + ".jpg").getDownloadUrl().toString();

                            // Toast.makeText(SettingActivity.this, downloadUrl, Toast.LENGTH_LONG).show();

                            uploadToDatabase.child("Shop User"+"/" + currentUserID + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {

                                    rootref.child("profile").setValue(uri.toString());
                                    Toast.makeText(SettingsActivity.this, "Image save to database ......!", Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(SettingsActivity.this, "Error :- " + e, Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();

                                }
                            });


                        } else {
                            String error = task.getException().toString();
                            Toast.makeText(SettingsActivity.this, "Error :- " + error, Toast.LENGTH_LONG).show();
                            loadingBar.dismiss();

                        }
                    }
                });
            }
        }


    }
}
