package com.online.online_mistry;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private View HomeView;
    private FirebaseAuth mAuth;
    private String currentUserID;
    private TextView CheckVerified;
    private DatabaseReference verRef;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        HomeView=inflater.inflate(R.layout.fragment_home, container, false);
        CheckVerified=HomeView.findViewById(R.id.textVerified);
        mAuth=FirebaseAuth.getInstance();
        checkVerification();

        return HomeView;
    }

    private void checkVerification() {

        try{
            verRef= FirebaseDatabase.getInstance().getReference();
            currentUserID=mAuth.getCurrentUser().getUid();

            verRef.child("Shops").child(currentUserID)
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                           // if(!dataSnapshot.hasChild("Document")){
                                CheckVerified.setVisibility(View.VISIBLE);

                         //   }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

        }catch (Exception e){
            Toast.makeText(getContext(),"Internet slow !!!",Toast.LENGTH_SHORT).show();


        }
    }

}
